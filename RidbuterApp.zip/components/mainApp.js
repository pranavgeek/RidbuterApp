import Navigation from './Navigation';

const MainScreen = () => {

  return (
      <Navigation />
  );
};


export default MainScreen;
